# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '70bec602dc436f605bce77dd7554235dc2f003423a2fa91dfa63c00f5cd2cc6bd357eee3b613470054322adc375023226b0f9d3daf843a51a487116703db2584'